# Bank-management-system
A quick and simple bank management system created using flask, JS and mySQL as part of this year's CS project.
#
<img width="1440" alt="Screenshot 2022-03-12 at 10 50 57 AM" src="https://user-images.githubusercontent.com/52439642/158005069-40f7a6f9-0aff-45c5-884e-1b41d310e3db.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005051-b9a39303-abea-473c-86ed-41f4f02a5cf1.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005104-43c6243a-dc2f-4051-ab05-52c08e5cd350.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005121-cd21f53d-4989-42c6-acf6-0c7765f95d25.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005134-17a9b4c8-33a2-48b4-996f-9ab201c54bf2.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005146-e3a0dbc0-f517-4a8e-8086-80ba25d2072a.png">
<img width="1440" alt="image" src="https://user-images.githubusercontent.com/52439642/158005153-e00e3f11-4627-4c04-9c42-4c6844286b86.png">

#
